export const SearchResult = {
    block: 'Block',
    transaction: 'Tx',
    address: 'Address',
    alias: 'Alias',
    unknown: 'Unknown'
};
