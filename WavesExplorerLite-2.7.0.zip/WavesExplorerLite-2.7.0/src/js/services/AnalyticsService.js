import {GoogleAnalyticsService} from './GoogleAnalyticsService';
import {AmplitudeAnalyticsService} from './AmplitudeAnalyticsService';

export class AnalyticsService {
    constructor(googleTrackingId, amplitudeApiKey) {
        this.google = new GoogleAnalyticsService(googleTrackingId);
        this.amplitude = new AmplitudeAnalyticsService(amplitudeApiKey);
    }

    initialize() {
        this.google.initialize();
        this.amplitude.initialize();
    }

    sendEvent(event) {
        this.google.sendEvent(event);
        this.amplitude.sendEvent(event);
    }
}
