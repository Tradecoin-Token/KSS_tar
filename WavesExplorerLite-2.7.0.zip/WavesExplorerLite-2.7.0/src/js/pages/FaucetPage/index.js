export {FaucetPage as default} from './FaucetPage.view';
