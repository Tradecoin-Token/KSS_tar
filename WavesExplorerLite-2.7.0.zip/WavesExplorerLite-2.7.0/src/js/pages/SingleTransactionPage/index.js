export {SingleTransactionPage as default} from './SingleTransactionPage.container';
