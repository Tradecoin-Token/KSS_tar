export {MainPage as default} from './MainPage.view';
