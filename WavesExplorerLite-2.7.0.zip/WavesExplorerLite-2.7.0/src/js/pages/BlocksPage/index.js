export {BlocksPage as default} from './BlocksPage.container';
