export {SingleBlockPage as default} from './SingleBlockPage.container';
