export {SingleAddressPage as default} from './SingleAddressPage.container';
