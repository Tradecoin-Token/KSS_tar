export {SingleAliasPage as default} from './SingleAliasPage.container';
