export {PeersPage as default} from './PeersPage.container';
