export {SingleAssetPage as default} from './SingleAssetPage.container';
