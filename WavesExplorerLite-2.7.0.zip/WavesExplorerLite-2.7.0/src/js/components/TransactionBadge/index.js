export {TransactionBadge as default} from './TransactionBadge.view';
