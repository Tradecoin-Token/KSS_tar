export {StateChangesInfoContainer as default} from './StateChangesInfo.container';
