export {EmptyData as default} from './EmptyData.view';
