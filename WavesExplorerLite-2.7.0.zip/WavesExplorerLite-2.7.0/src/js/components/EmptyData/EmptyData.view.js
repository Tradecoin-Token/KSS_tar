import React from 'react';

export const EmptyData = () => (
    <div className="empty-icon-wrapper">
        <div className="empty-icon"></div>
        <div className="empty-label">No data</div>
    </div>
);
