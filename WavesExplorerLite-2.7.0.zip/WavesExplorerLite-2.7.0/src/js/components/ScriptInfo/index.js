export {RoutedScriptInfoContainer as default} from './ScriptInfo.container';
