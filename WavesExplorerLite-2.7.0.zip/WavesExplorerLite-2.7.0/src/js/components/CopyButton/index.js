export {CopyButtonContainer as default} from './CopyButton.container';
