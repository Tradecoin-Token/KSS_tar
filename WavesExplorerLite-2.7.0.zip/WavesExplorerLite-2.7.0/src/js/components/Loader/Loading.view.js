import React from 'react';

export const Loading = () => (
    <div className="loading">
        <div className="loading-icon"></div>
    </div>
);
