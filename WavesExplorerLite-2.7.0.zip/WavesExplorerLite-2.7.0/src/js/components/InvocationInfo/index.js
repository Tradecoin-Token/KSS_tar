export {InvocationInfoView as default} from './InvocationInfo.view';
