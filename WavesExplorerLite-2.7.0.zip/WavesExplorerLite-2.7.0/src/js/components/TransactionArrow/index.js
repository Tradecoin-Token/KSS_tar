export {TransactionArrow as default} from './TransactionArrow.view';
