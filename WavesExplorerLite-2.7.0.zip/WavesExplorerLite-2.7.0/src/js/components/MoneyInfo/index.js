export {MoneyInfo as default} from './MoneyInfo.view';
