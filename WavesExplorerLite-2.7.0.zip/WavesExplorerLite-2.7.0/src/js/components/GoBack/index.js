export {RoutedGoBack as default} from './GoBack.container';
