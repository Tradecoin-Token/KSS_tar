export {CurrencyRef as default} from './CurrencyRef.view';
