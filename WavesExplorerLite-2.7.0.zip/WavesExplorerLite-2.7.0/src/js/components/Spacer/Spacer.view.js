import React from 'react';

export const Spacer = ({size}) => {
    return <span style={{marginLeft: `${size}px`}}></span>
};
