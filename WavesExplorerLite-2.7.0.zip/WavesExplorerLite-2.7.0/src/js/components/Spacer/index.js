export {Spacer as default} from './Spacer.view';
