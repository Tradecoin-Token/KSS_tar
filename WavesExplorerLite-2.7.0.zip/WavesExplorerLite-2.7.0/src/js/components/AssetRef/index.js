export {RoutedAssetRef as default} from './AssetRef.view';
