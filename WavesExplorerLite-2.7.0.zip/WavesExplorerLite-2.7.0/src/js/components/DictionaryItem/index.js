export {DictionaryItem as default} from './DictionaryItem.view';
