export {RoutedEndpointRef as default} from './EndpointRef.view';
