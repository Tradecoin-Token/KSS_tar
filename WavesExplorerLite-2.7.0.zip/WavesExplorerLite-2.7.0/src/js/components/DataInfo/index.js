export {DataInfo as default} from './DataInfo.view';
