export {RoutedBlockRef as default} from './BlockRef.view';
