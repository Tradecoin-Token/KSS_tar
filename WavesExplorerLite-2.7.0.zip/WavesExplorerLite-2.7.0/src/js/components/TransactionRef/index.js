export {RoutedTransactionRef as default} from './TransactionRef.view';
