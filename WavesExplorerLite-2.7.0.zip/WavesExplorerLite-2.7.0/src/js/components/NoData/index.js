export {NoData as default} from './NoData.view';
