export {Dictionary as default} from './Dictionary.view';
