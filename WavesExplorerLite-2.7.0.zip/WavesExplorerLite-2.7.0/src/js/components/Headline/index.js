export {Headline as default} from './Headline.view';
